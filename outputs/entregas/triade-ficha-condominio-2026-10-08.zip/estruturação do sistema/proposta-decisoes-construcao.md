# Proposta de decisões para construir o TRÍADE Condo

## Decisão mais recente — atendimento humano opcional e número em proposta

Atendimento humano pelo WhatsApp é opcional: condomínio pode assumir com equipe própria ou contratar TRÍADE para atender. A contratação do serviço humano é separada da plataforma. Ficha guarda modelo escolhido, referência de contratação quando TRÍADE, pessoas autorizadas e horários por condomínio. Não presumir contratação, equipe, capacidade ou suporte 24h; troca de equipe/revogação mantém histórico e autoria. Produto continua com responsáveis/andamento/retornos essenciais, sem inventar pessoa disponível ou assumir IA/automação para substituir atendimento.

A sugestão de um número institucional exclusivo/próprio por condomínio não recebeu aprovação explícita, conforme esclarecimento mais recente de Carolina; permanece PROPOSTA. Isso prevalece sobre textos anteriores que o descreviam como pré-requisito de adesão. WhatsApp permanece canal do morador; topologia dos números e roteamento seguro por condomínio continuam a decidir, sem conta real ou integração.


**Atualização de aprovação parcial:** ficha por condomínio, acessos próprios de secretária/delegados, permissões individuais, responsáveis, dias/horários e mensagem foram aprovados. Os demais padrões e escolhas deste documento continuam propostas.

08/10/2026 • para revisão de Carolina • recomendações, não regras aprovadas ou implementadas.

Esta proposta resolve as sete pendências da auditoria com padrões concretos e escolhas explícitas. Aprovar uma recomendação atualiza a especificação; não autoriza automaticamente implantação, números reais, contato externo ou compra. Os materiais atuais continuam sendo planejamento e protótipos, sem backend, autenticação, WhatsApp ou pagamentos reais.

## Direção recomendada

Construir primeiro o MVP já aprovado, como uma aplicação única organizada em módulos: dois painéis web, serviço de aplicação com autorização, banco relacional, arquivos privados e processamento de mensagens em segundo plano. Evitar dividir cedo em vários serviços independentes. É recomendação de proporcionalidade para este projeto, não conclusão de que toda empresa deve usar essa arquitetura.

Morador continua somente no WhatsApp institucional, sem portal/login. Síndico opera o próprio condomínio; Carolina administra a carteira e libera apenas o contratado. Atendimento completo é inseparável, com conteúdos básicos. Agenda/manutenção são próximas etapas; propostas/orçamentos fora do inicial. QR/receptor, financeiro condomínio e armários não entram nesta construção.

Plataforma organiza a rotina do condomínio; serviço humano TRÍADE entrega implantação/orientação/documentação conforme acordo. Não presumir equipe TRÍADE recorrente, atendimento humano 24 horas, execução de reparos ou compras. O primeiro responsável pela fila deve ser o síndico ou pessoa autorizada por ele, realmente disponível.

## R1 — Vínculos e permissões

**Padrão recomendado.** Separar três coisas: identidade da pessoa, vínculo com condomínio/unidade e ações permitidas. Uma pessoa pode ter mais de um vínculo, mas cada operação acontece em um condomínio autorizado específico. Número de telefone sozinho não prova que a pessoa pode consultar qualquer dado.

**Comportamento do MVP.** Carolina cadastra cliente e síndico autorizado. Síndico confirma contatos/unidades; equipe de implantação pode preparar cadastro, mas não aprová-lo por padrão. Contato não confirmado pode enviar uma solicitação de verificação, sem receber histórico/documentos restritos nem confirmar publicamente nomes ou existência de moradores. A verificação pode ser manual no primeiro MVP; não exigir CPF no cadastro básico.

Proposta de matriz: Carolina administra carteira/contratação/liberação e delegações; implantação edita dados preparatórios e pendências dos clientes atribuídos; financeiro interno registra/confronta pagamentos desses clientes; suporte verifica pedidos de acesso atribuídos. Síndico administra fila e conteúdos do seu condomínio. Nenhum funcionário recebe esses papéis automaticamente. Acesso de suporte a conversa deve ser excepcional, com motivo, cliente atribuído e registro; proposta de aprovação do síndico para esse acesso.

No servidor, negar por padrão e validar pessoa, ação, vínculo e objeto em cada pedido, incluindo arquivos, buscas e tarefas automáticas. Essas práticas são documentadas pela [OWASP — autorização](https://cheatsheetseries.owasp.org/cheatsheets/Authorization_Cheat_Sheet.html). Capacidade disponível exige contratado E liberado; permissão pessoal é uma verificação adicional.

**Razão.** Evita misturar carteira interna, direitos do síndico e dados do morador. Também funciona em prédio simples sem porteiro, sem criar cargos fictícios.

**Carolina precisa decidir.** Quem da equipe exercerá cada função? O síndico pode designar substituto/delegado? A verificação manual pelo síndico será o padrão inicial? Quem autoriza acesso excepcional de suporte? Como comprovar mudança de síndico quando houver dúvida? Não prescrever ata universal: aceitar documentação pertinente ao caso, conferida por responsável designado.

**Aceite.** Dois condomínios e pessoas com múltiplos vínculos: nenhuma consulta/alteração/anexo cruza cliente; troca de identificador não libera dados. Contato pendente não consulta conteúdo restrito. Remover vínculo bloqueia novos acessos e preserva autoria anterior. Funcionário de implantação não confirma pagamento nem concede acesso por ter esse papel.

## R2 — WhatsApp, falhas e passagem para atendimento humano

**Padrão recomendado.** Usar integração oficial do WhatsApp Business Platform por adaptador próprio da aplicação. Escolher entre acesso direto e provedor oficial após conferir número, titularidade, migração, suporte e custo total. Não automatizar sessão de WhatsApp Web como base da plataforma.

**Comportamento do MVP.** Cada canal institucional tem vínculo explícito com um condomínio. Receber evento, verificar autenticidade conforme provedor, registrar uma vez e encaminhar à fila. Responder pela mesma origem institucional. Separar estado do pedido de estado da mensagem: recebida; envio pendente; aceita pelo provedor; entregue quando confirmado; falhou; resultado ainda desconhecido. Leitura só quando houver sinal válido; nenhum estado comprova solução.

Gravar a intenção de envio junto da alteração de negócio e processar depois, para não perder retorno quando a comunicação falhar. Proposta inicial: até cinco tentativas totais, com intervalo crescente e aleatoriedade, apenas em falhas transitórias. É parâmetro nosso para revisão, não exigência do WhatsApp. Erro permanente ou limite atingido vai à fila de falhas com responsável; intervenção manual registra motivo e nova tentativa. Identificador de evento/ação impede duplicações; callback atrasado não regride entrega confirmada.

Responsável humano: síndico ou substituto autorizado acompanha a fila, assume e atualiza próximo retorno. Confirmação automática deve dizer que o pedido foi registrado, sem afirmar que alguém está trabalhando. Quando não houver pessoa/executor disponível, mostrar pendência real. Não incluir IA nem distribuição automática neste MVP como consequência desta proposta.

A [documentação oficial Twilio de WhatsApp](https://www.twilio.com/docs/whatsapp/api) distingue janela de conversa, templates, permissões de comunicação e callbacks. Usá-la como referência técnica, não seleção do fornecedor: janela de 24 horas indicada ali não é prazo de atendimento. Conferir regras do provedor escolhido antes de integrar. Registrar preferências/autorização de envio e pedidos de não receber avisos, sem confundir exigências do canal com base legal de todo tratamento de dados.

**Razão.** Pedido salvo precisa continuar visível mesmo se a mensagem falhar. Evita confirmação falsa, resposta duplicada e fila sem dono.

**Carolina precisa decidir.** Responsável/substituto e horários de acompanhamento por condomínio; texto de expectativa fora desse horário; quem acompanha falhas de integração; quais avisos proativos são essenciais e quais são opcionais. Desenvolvedor compara caminhos oficiais e apresenta titularidade/migração/suporte/custo; escolher fornecedor não é tarefa do morador.

**Aceite.** Mesmo evento três vezes gera um pedido. Canal de A não entrega conteúdo de B. Falha transitória repete de forma controlada; erro permanente fica visível. Callback fora de ordem não altera entrega para pendente. Contato revogado não recebe novo conteúdo. Assumir atendimento tem autoria, e resposta humana não é duplicada por confirmação automática.

## R3 — Publicação e consulta de documentos

**Padrão recomendado.** Arquivo privado na plataforma, metadados/versionamento e público autorizado por publicação. Síndico prepara, revisa destinatários e publica. Para documentos básicos destinados aos moradores, entrega/consulta pelo próprio WhatsApp: texto, resumo ou arquivo permitido. Não criar tela externa de morador para resolver esta pendência.

**Comportamento do MVP.** Rascunho não é enviado. Publicação registra autor, data, versão e destinatários; referência de público inicial: todos os contatos confirmados do condomínio ou unidades/contatos escolhidos explicitamente. Após troca de vínculo, recalcular destinatários antes de cada novo envio. Versão substituída deixa de ser a versão corrente; histórico interno preserva alteração.

Começar com PDF para documentos e texto para comunicados. Proposta técnica inicial de limite: 10 MB por arquivo, respeitando limite menor do provedor escolhido. Validar formato/conteúdo e inspecionar antes da publicação; arquivo ainda não verificado fica indisponível. Nome fornecido pelo usuário não define caminho físico. A [OWASP — upload de arquivos](https://cheatsheetseries.owasp.org/cheatsheets/File_Upload_Cheat_Sheet.html) recomenda controle de tipos/tamanhos, armazenamento protegido e verificação dos arquivos. O limite de 10 MB é proposta TRÍADE, não regra da fonte.

Revogar vínculo impede novas consultas/envios; não promete apagar arquivo que já foi baixado ou encaminhado. Se conteúdo precisar de controle rigoroso após compartilhamento, não distribuí-lo como arquivo comum: definir resumo permitido ou outra solução compatível com WhatsApp antes de implementar. URLs temporárias podem existir entre backend/provedor para transporte técnico, sem transformar consulta do morador em portal e sem expor pasta pública.

**Razão.** Mantém jornada simples, separa publicação de aprovação de regras pelo condomínio e evita prometer revogação impossível após download.

**Carolina precisa decidir.** Aprovar público padrão e envio de PDF para documentos básicos? Quais tipos de conteúdo jamais devem ser distribuídos aos moradores? Quem aprova conteúdo elaborado pela TRÍADE? Qual prazo de retenção por classe de documento e finalidade? Retenção não deve ser inventada como um número universal.

**Aceite.** Rascunho não chega ao WhatsApp; destinatário não autorizado não recebe nem consulta arquivo; conteúdo de A não aparece em B. Arquivo rejeitado não publica. Substituição identifica a versão vigente. Revogado não recebe nova versão; interface informa limite após download. Notas e documentos de trabalho internos ficam separados.

## R4 — Configuração por condomínio e edição concorrente

**Padrão recomendado.** Configuração pequena, com identificadores estáveis e versão: responsáveis vinculados, categorias opcionais, prioridades de significado claro e etapas ligadas a aberto/em andamento/encerrado. Não criar construtor de processos ilimitado.

**Comportamento do MVP.** Renomear etapa altera apresentação futura sem apagar o valor/autoria histórica. Etapa usada pode ser desativada para novos registros; migrar casos abertos exige selecionar destino e registrar decisão. Desativar responsável com casos em andamento exige substituição ou pendência explícita de acompanhamento, sem atribuir executor inexistente.

Cada alteração carrega a versão lida. Se outra pessoa já salvou, rejeitar a sobrescrita silenciosa e mostrar versão nova junto do rascunho da pessoa. Ela decide reaplicar. Atualizar dados e histórico na mesma transação. O [RFC 9110 — If-Match](https://www.rfc-editor.org/rfc/rfc9110.html#name-if-match) descreve precondição usada para prevenir perda de atualização; a aplicação pode implementar o controle equivalente pela versão do registro.

Proposta de conclusão: síndico/responsável autorizado registra resultado e resumo ao morador; concluir não depende de foto ou aceite obrigatório do morador. Se morador voltar pelo WhatsApp sobre o mesmo problema, registrar mensagem e pedir decisão autorizada de reabrir ou novo pedido. Não reabrir automaticamente por qualquer texto recebido. Próximo retorno acompanha caso aberto; encerrado preserva o retorno anterior e o resultado, sem gerar promessa futura automática.

**Razão.** Adapta o processo à demanda sem perder história ou alterações de outra pessoa. Troca de lâmpada e consulta de regra não exigem as mesmas etapas.

**Carolina precisa decidir.** Quem configura etapas/responsáveis e quem encerra/reabre? Aprovar desativação sem apagar histórico e confirmação explícita de migração? Necessita revisão de conclusão por outra pessoa em algum caso concreto? Não obrigar dupla aprovação em todas as demandas.

**Aceite.** Dois operadores salvando a mesma versão recebem conflito compreensível; ninguém perde rascunho. Renomear/desativar etapa mantém histórico. Casos em curso continuam legíveis. Processo varia por condomínio e pedido; atendimento completo continua sem agenda, orçamento, foto ou checklist obrigatórios.

## R5 — Recuperação e ciclo de acesso

**Padrão recomendado.** Usar mecanismo de identidade mantido e bem suportado, em vez de inventar autenticação artesanal. Como proposta de experiência inicial: usuário do painel com e-mail verificado e senha; recuperação enviada somente ao e-mail já verificado. Funcionário inicia/acompanha suporte, mas não escolhe senha nem visualiza segredo. Proponho MFA para Carolina e equipe com poderes administrativos; disponibilidade ao síndico, com exigência a decidir conforme risco/usabilidade.

**Comportamento do MVP.** Solicitação devolve resposta neutra. Após checagem de vínculo quando envolver suporte, mecanismo aleatório de uso único e expiração, invalidação de mecanismos anteriores e proteção contra tentativas excessivas. Proposta de validade: 30 minutos, a validar com a experiência real. Após sucesso, exigir novo login e revogar sessões antigas administradas pela aplicação, verificando capacidades do serviço escolhido. A [OWASP — recuperação de senha](https://cheatsheetseries.owasp.org/cheatsheets/Forgot_Password_Cheat_Sheet.html) orienta resposta uniforme e tokens seguros, de uso único e expiração. Não define o prazo de 30 minutos desta proposta.

Troca de síndico não é simples reset: Carolina valida substituição, revoga vínculo anterior e concede novo vínculo com conta própria. Trocar e-mail de recuperação exige procedimento separado; não enviar para endereço que o solicitante acabou de indicar. Notificar mudança ao canal anterior quando seguro/pertinente, conforme política aprovada. Tokens e senhas não entram em notas, logs, exportações ou evidências.

Propor recuperação administrativa de emergência: responsável suplente designado e códigos de recuperação protegidos, fora do painel cotidiano, com registro e revisão do uso. Se não houver suplente agora, documentar procedimento excepcional verificável; não criar acesso para uma pessoa não indicada. Sessões reais devem expirar e ser invalidadas no servidor; fechar navegador não basta. Referências: [OWASP — sessão](https://cheatsheetseries.owasp.org/cheatsheets/Session_Management_Cheat_Sheet.html) e [autenticação/MFA](https://cheatsheetseries.owasp.org/cheatsheets/Authentication_Cheat_Sheet.html).

**Razão.** Protege substituições e perdas de acesso sem transformar funcionário em conhecedor de senhas. Morador permanece sem conta a recuperar.

**Carolina precisa decidir.** E-mail verificado é viável para todos os síndicos? Quem valida substituições e casos sem acesso ao e-mail? Quem será suplente administrativo? Aprovar MFA da equipe privilegiada? Escolher serviço/implementação com desenvolvedor, sem contratar por esta proposta.

**Aceite.** Token usado/expirado não funciona; solicitação não revela conta; segredo não aparece nos logs. E-mail recém-informado não recebe redefinição sem validação. Usuário removido e sessão revogada não fazem nova operação. Troca de síndico mantém autoria histórica e não compartilha conta.

## R6 — Competência e pagamentos internos à TRÍADE

**Padrão recomendado.** Separar contratação, obrigação de pagamento e registros de recebimento/conferência. Não usar uma única ficha sobrescrita todo mês.

**Comportamento do MVP.** Cada obrigação contém cliente, referência do serviço/acordo, competência ou período, vencimento, moeda e valor acordado quando conhecido. Mensalidade pode usar ano/mês; implantação pontual usa período/referência do serviço, sem competência mensal inventada. Criar obrigações manualmente no primeiro MVP; recorrência de cobrança não está autorizada.

Registrar recebimentos com data, valor conhecido, referência e responsável pela conferência; permitir alocar parcial à obrigação correta. Só calcular saldo quando obrigação e recebimentos forem conhecidos/conferidos. Recebimento ainda não identificado fica pendente, sem atribuição ao cliente errado. Correção usa evento de ajuste/estorno lógico com motivo e referência, preservando registro anterior; não apaga nem movimenta banco. Evitar duplicidade de confirmação por referência/identificador interno.

Preferir moeda explícita e representação monetária exata, nunca ponto flutuante para somas financeiras. Se PostgreSQL for escolhido, a [documentação de tipos numéricos](https://www.postgresql.org/docs/current/datatype-numeric.html) diferencia numeric exato de tipos aproximados. É referência de implementação, não escolha tecnológica já aprovada.

Situação operacional deriva de vencimento/valor/conferência conhecidos, com divergência/revisão explícita. Contratação/liberação permanece independente: atraso não bloqueia automaticamente. Não incluir boleto, gateway, cobrança automática, emissão fiscal, financeiro do condomínio ou contabilidade completa.

**Razão.** Permite acompanhar meses, implantação, parcial e problema sem perder histórico ou confundir ausência de valor com zero.

**Carolina precisa decidir.** Quais serviços têm mensalidade versus cobrança pontual? Quem registra e quem confere? Uma pessoa pode acumular no início? Como tratar crédito excedente/adiantamento — registrar pendência manual no primeiro MVP ou definir regra? Não aplicar compensação automática antes de acordo.

**Aceite.** Registrar duas competências mantém ambas; parcial conhecido calcula saldo correto; valor desconhecido não gera saldo fictício; correção preserva antes/depois; pagamento duplicado não confirma duas vezes. Problema financeiro não altera funções liberadas.

## R7 — Revisão visual e fluxos no navegador

**Padrão recomendado.** Antes de construir telas reais, realizar sessão de teste guiada do protótipo com Carolina e pelo menos um participante representando o síndico, quando houver autorização para envolver essa pessoa. Depois, repetir os mesmos roteiros na implementação. Não tratar preferência estética como prova de usabilidade.

**Comportamento do MVP.** Painéis responsivos e claros, com navegação por teclado, foco visível, rótulos, mensagens de erro e confirmação, estados vazios, carregamento e falha. Proposta: usar WCAG 2.2 nível AA como alvo de qualidade, sem afirmar certificação ou obrigação jurídica específica. A [WCAG 2.2 — W3C](https://www.w3.org/TR/WCAG22/) contempla requisitos de teclado, foco e apresentação adaptável.

Roteiro: Carolina cadastra cliente, contrata/libera base, registra implantação e pagamento; síndico recebe demanda, muda responsável/prioridade/etapa, combina retorno sem estimativa, responde e conclui; publica conteúdo autorizado; suporte simula recuperação. Testar também erros, vínculo revogado, outro condomínio e mensagem que falhou. Agenda/manutenção continuam fora.

Testar em navegador/ambiente permitido: desktop Chromium e Safari, celular Android/iPhone quando disponíveis, teclado e ao menos uma avaliação com leitor de tela. A lista final de navegadores/dispositivos depende dos usuários reais. Ferramentas automáticas podem ajudar, mas não substituem observação/manual. Registrar ambiente, captura quando permitida, resultado e tarefa de ajuste.

No painel local de execução: uma pessoa/aba de edição, exportação antes/depois, teste de importação/backup e conflitos; isso não vira sincronização de equipe. A restrição atual de abertura de arquivo local neste ambiente permanece: nenhuma revisão visual foi realizada nem será contornada nesta proposta. Programar o teste em ambiente autorizado, não declarar concluído.

**Razão.** Evita desenvolver tela que só parece correta no código. Leva os fluxos e falhas já especificados para verificação observável.

**Carolina precisa decidir.** Quem participa e quais aparelhos/navegadores realmente usa? Quem aceita os fluxos e registra evidências? Aprovar o alvo AA e prioridade para correções que impeçam tarefa básica? Não exigir compra de aparelho por esta proposta.

**Aceite.** Pessoas completam os roteiros críticos, inclusive erro/retomada, sem ajuda constante; teclado não prende foco; celular não esconde ação essencial. Nenhuma prévia envia mensagem real. Resultado e ambiente registrados; bloqueador de fluxo vira tarefa antes de aceite.

## Arquitetura proposta e construção proporcional

Proposta funcional: painéis → serviço de aplicação → identidade/vínculos, clientes/liberação, atendimento/conteúdo, implantação, pagamentos internos e auditoria → banco relacional + armazenamento privado. Adaptador WhatsApp → entrada validada/deduplicada → registros → fila de envio → callback/resultado → responsável humano. Módulos compartilham o condomínio autorizado, não permissões indiscriminadas.

Padrão recomendado: aplicação modular única e worker separado por responsabilidade operacional, sem criar muitos serviços distribuídos. Uma transação salva mudança e intenção de mensagem; worker trata comunicação externa. Banco é a fonte de estado do produto, não localStorage. Controle de versão evita perda de atualização. Logs operacionais registram identificadores e resultados sem copiar senhas, tokens ou todo conteúdo pessoal.

Sugestão técnica para discussão: manter TypeScript/Node e PostgreSQL como candidatos já documentados, se o desenvolvedor tiver domínio e capacidade de suporte. Não há pacote/framework/versão/hospedagem escolhido. Banco relacional com transações é mais relevante que uma marca específica. Se PostgreSQL for adotado, isolamento por linha pode somar defesa, mas não substitui autorização da aplicação; proprietários/superusuários têm particularidades que exigem configuração/teste. Ver [documentação oficial de Row Security](https://www.postgresql.org/docs/current/ddl-rowsecurity.html).

Recomendo serviço de identidade mantido, arquivos privados e infraestrutura com cópias/recuperação e monitoramento, escolhidos depois de comparar acesso administrativo, portabilidade, suporte, custo e operação da equipe. Evitar dependência de automação visual de WhatsApp, planilha como banco ou autenticação caseira improvisada. Testes do futuro backend precisam provar isolamento e falhas; o protótipo não prova isso.

## Privacidade, retenção e operação humana

Manter cadastro mínimo, finalidade de cada campo e acesso por necessidade. Propor inventário simples: dados de contato/vínculo, atendimentos/conteúdos, implantação, pagamentos internos e logs. Para cada classe, identificar quem decide finalidade, quem opera, destinatários, prazo de retenção e procedimento de correção/exclusão. Não coletar CPF no básico por precaução genérica.

As orientações da [ANPD sobre segurança](https://www.gov.br/anpd/pt-br/centrais-de-conteudo/materiais-educativos-e-publicacoes/anonimizado___guia_orientat-_seg_da_inf_p_atpp.pdf) incluem controle de acesso e treinamento. A [ANPD sobre agentes de tratamento](https://www.gov.br/anpd/pt-br/centrais-de-conteudo/materiais-educativos-e-publicacoes/guia_agentes_de_tratamento_e_encarregado___defeso_eleitoral.pdf) distingue responsabilidades conforme a atuação. Mapear TRÍADE, condomínio e fornecedores por operação; não declarar automaticamente quem é controlador/operador em todos os casos. Enquadramento, bases legais e prazos aplicáveis precisam de avaliação apropriada, sem supor que consentimento é a única base nem que o projeto tem determinada dispensa legal.

Propor treinamento da equipe para não expor carteira/conversas, não compartilhar contas, distinguir rascunho de aprovado e tratar pedido de acesso/dados. Suporte técnico da plataforma não é execução de reparo, atendimento recorrente contratado ou canal de emergência. Cópia de segurança só é útil quando restauração é testada; combinar objetivo de recuperação/capacidade com o desenvolvedor antes de prometer disponibilidade.

## Ordem de construção e marcos de aceite

1. Revisar R1–R7; registrar aprovado/ajustar/adiar e responsáveis pelas escolhas abertas. Fechar R1 e identidade/ambientes antes da fundação; levantar viabilidade WhatsApp cedo sem conectar número real.
2. Fundação: esquema/vínculos/autorizações, autenticação, auditoria, controle de versão e arquivos privados. Provar isolamento A/B e revogação com dados de teste.
3. Carolina: cliente, contratação/liberação e atribuições; configuração mínima e painel síndico. Sem ativar adicionais futuros.
4. Atendimento completo e conteúdos básicos com adaptador simulado. Provar retorno, histórico, estados, destinatários e edição concorrente.
5. Implantação/manual, obrigações/recebimentos internos e recuperação segura. Todos fazem parte do MVP; ordem interna pode acompanhar dependências.
6. Integrar WhatsApp oficial após aprovação do caminho técnico/número/ambiente. Provar deduplicação, falhas, callbacks e acompanhamento humano; sem clientes reais por padrão.
7. Revisão visual/acessibilidade, restauração e suporte; conferir evidências em MVP-16/17. Piloto só depois de autorização específica e limites acordados.

A cada tarefa: objetivo → responsável → sessão de trabalho com resumo → arquivo/commit/teste real → revisão → aceite. Encerrar sessão não conclui tarefa. AUD-02 a AUD-08 continuam pendentes até decisão/evidência; esta proposta não muda seus estados. Sem preço/prazo de entrega prometido.

## Dependências, riscos e custos a levantar

Mensagens/template/provedor, números e migração; hospedagem/banco/arquivos e tráfego; identidade/MFA/envio de recuperação; inspeção de arquivos; cópias/monitoramento; trabalho do desenvolvedor e capacidade humana de implantação/suporte. Comparar custo total por quantidade de condomínios, contatos, arquivos e mensagens, não apenas mensalidade anunciada. Pedir orçamento com premissas e limites; não adotar preços antigos da pesquisa como atuais.

Riscos prioritários: titularidade/número incompatível, vínculo de contato errado, público documental amplo demais, fila sem pessoa disponível, envio duplicado/perdido, revogação incompleta, mudanças simultâneas e perda de registros locais. Testes e políticas R1–R7 tratam esses riscos sem ampliar produto. Retenção, autorização de conteúdo, atendimento humano e modelo comercial precisam de participação de Carolina; versões, transações, segurança e alternativas tecnológicas devem ser avaliadas pelo desenvolvedor.

## Quadro de decisões para aprovação

| ID | Padrão que recomendo aprovar | Escolha específica ainda necessária | Tarefa relacionada |
|---|---|---|---|
| R1 | Vínculo confirmado + permissão por função/cliente/ação; verificação manual inicial pelo síndico | Delegados, equipe e suporte excepcional | AUD-02 |
| R2 | Canal oficial, fila durável, falhas visíveis e responsável humano do condomínio | Provedor/número, horários e destinatários | AUD-03 |
| R3 | Arquivos privados; síndico publica PDF/texto autorizado no próprio WhatsApp; versão e público explícitos | Conteúdo permitido, público e retenção | AUD-04 |
| R4 | IDs estáveis, desativação/migração registrada e conflito de edição sem sobrescrita silenciosa | Quem configura/conclui/reabre | AUD-05 |
| R5 | Recuperação pelo canal já verificado, segredo de uso único, sessões revogáveis; MFA equipe privilegiada | E-mail, suplente, verificação excepcional e serviço de identidade | AUD-06 |
| R6 | Obrigação por competência/serviço + recebimentos/conferências/ajustes preservados | Papéis, periodicidade e excedentes | AUD-07 |
| R7 | Revisão guiada de fluxos/erros e alvo WCAG AA, com evidências de ambiente real permitido | Participantes, dispositivos e responsável pelo aceite | AUD-08 |

Carolina pode responder “aprovar R1–R7 com estas escolhas”, ou aprovar cada área separadamente. Aprovação dos padrões não fecha automaticamente as escolhas da terceira coluna. Nenhuma recomendação deste arquivo foi aplicada como regra de produto.

## Fontes e limite da pesquisa

Consulta em 08/10/2026, somente fontes primárias oficiais, com links junto dos pontos que sustentam. OWASP oferece práticas de segurança; W3C requisitos de acessibilidade; RFC semântica HTTP; PostgreSQL documentação de comportamento técnico; Twilio regras de sua integração oficial; ANPD orientação de privacidade. Essas fontes não certificam TRÍADE nem escolhem fornecedor.

A página de webhooks Meta consultada não abriu neste mecanismo; não usei seu conteúdo não acessível para afirmar número/prazo de retries. Referência de WhatsApp verificável usada aqui é a documentação oficial Twilio; regras de um provedor não são transferidas automaticamente para outro. Números de tentativas/validade/tamanho sugeridos são parâmetros da proposta, sujeitos a revisão, não obrigações extraídas das fontes.

Referências do projeto: [MVP aprovado](especificacao-mvp.md), [auditoria](relatorio-revisao-desenvolvimento.md), [próximas etapas](proximas-etapas.md), [manual](manual-implantacao.md), [protótipo](prototipo-paineis.html), [execução](../outputs/triade-condo/construcao/index.html) e [mapa](../mapa-da-empresa.html).

## Aprovação parcial posterior

Aprovada a ficha por condomínio no painel Carolina com pessoas/função/permissões próprias, secretária/delegados, responsáveis, dias/horários e mensagem fora do expediente, com histórico. Aprovação de despesas reservada ao síndico como fronteira futura; sem módulo de despesas no MVP. Demais recomendações R1–R7 não aprovadas automaticamente. Ver ajuste vigente na especificação e protótipo.
