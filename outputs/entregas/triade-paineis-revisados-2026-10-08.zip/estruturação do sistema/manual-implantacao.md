# Manual de implantação de condomínio cliente

## Escopo vigente confirmado em 08/10/2026

MVP aprovado: atendimento completo WhatsApp institucional, comunicados/documentos básicos, painel síndico e painel Carolina com clientes/contratação/liberação, implantação/manual, registro pagamentos à TRÍADE e recuperação segura de acesso síndico. Agenda e coordenação de manutenção ficam depois; orçamentos fora do inicial. O texto abaixo preserva visão anterior/ampliada; não torna conjuntos adicionais parte do MVP. [Especificação vigente](especificacao-mvp.md) prevalece. Propostas de estados, telas e mecanismos continuam sujeitas à revisão. Nenhum backend/autenticação/WhatsApp real implementado.


Versão para revisão — 08/10/2026. Roteiro interno da TRÍADE para qualquer funcionário autorizado à implantação. Ainda não há produto/autenticação/integração implementados: passos técnicos são preparação e critérios para execução futura. Não marcar configuração, envio ou teste como concluído sem execução real.

## Como usar

Carolina designa responsável e substituto, condomínio e escopo acordado. O funcionário segue as etapas e registra feito, pendente ou não aplicável, com motivo, responsável e próxima providência. Adaptar a sequência ao cliente; não inventar informação ou resolver decisão fora de sua atribuição. Em bloqueio, informar Carolina e combinar encaminhamento. Este checklist organiza o serviço interno; não cria fluxo obrigatório para atendimento, manutenção ou troca de lâmpada do condomínio.

## 1. Abrir ficha de implantação

**Responsável:** Carolina confirma contratação; funcionário autorizado organiza ficha.

Conferir condomínio cliente, contato do síndico/responsável autorizado, referência do acordo, conjuntos contratados/liberáveis e escopo dos serviços (implantação, orientação e apoio documental). Registrar responsável interno, pendências e data de próxima revisão. Não inventar preço/inclusão. Não criar cliente duplicado nem misturar dados de outro prédio.

**Entrega/critério:** ficha e escopo confirmados; divergência de contrato encaminhada à Carolina antes de liberar recurso.

## 2. Levantar dados necessários e contexto

**Responsável:** funcionário solicita pelo canal acordado; síndico fornece/confirma.

Levantar identificação do condomínio e unidades, responsáveis reais, WhatsApp institucional próprio e contatos autorizados, organização/procedimentos existentes, regras/documentos vigentes e necessidades de configuração. Cadastro breve de morador: nome, telefone e apartamento; CPF somente se necessário ao financeiro futuro, não ao básico. Coletar somente o necessário por etapa, sem dados reais neste planejamento.

Verificar se o condomínio tem número institucional; se não, registrar que precisa providenciar para adesão. Provedor/API, custos/migração e viabilidade técnica ficam para definição futura. Não usar automaticamente WhatsApp pessoal do síndico como institucional. Confirmar vínculos/destinatários; não presumir quem está em casa.

**Entrega/critério:** dados conferidos, lacunas atribuídas a responsável e acesso autorizado definido. Sem informação, marcar pendente; não preencher por suposição.

## 3. Organizar documentos e validação

**Responsável:** funcionário de implantação/documentação dentro do escopo; condomínio valida/aprova.

Catalogar o que foi fornecido e a versão vigente. Se falta documento e apoio está no escopo, elaborar rascunho; se existente precisa ajuste, revisar/propor alteração. Registrar autor, versão, pendência e responsável pela validação; revisão profissional quando aplicável a definir com Carolina.

Atas refletem reuniões/decisões reais; sem fabricação retroativa. Regras aprovadas pelo condomínio, sem regularização automática ou assessoria jurídica presumida. Rascunhos/notas internas ficam com TRÍADE; versão final aprovada pode ser disponibilizada no produto conforme permissão.

**Entrega/critério:** relação de documentos fornecidos/aprovados e pendências, com versões finais identificadas. Não publicar rascunho como aprovado.

## 4. Preparar configuração e acesso futuros

**Responsável:** funcionário autorizado prepara; execução técnica pelo responsável designado quando houver sistema.

Conferir contratado × liberado por condomínio, base completa e funções adicionais acordadas. Definir usuários autorizados do painel síndico e responsabilidades; recuperação/revisão de acesso segue procedimento de suporte, sem funcionário ver senha.

Com o síndico, propor responsáveis, prioridades, categorias, etapas e retornos simples. Respeitar processos diferentes e histórico. Não exigir foto/ata/checklist universal nem remover fila/retorno como extra. Agenda/manutenção/ampliados em revisão; orçamento/propostas fora do desenvolvimento inicial; QR/sonoro não aprovado como MVP.

**Teste futuro:** isolamento entre clientes, conjuntos corretos no painel, ausência de notas internas, conteúdo autorizado e destinatários WhatsApp. Sem conta/login/API funcionando agora, registrar “preparado / execução técnica pendente”, nunca “implantado”.

**Entrega/critério:** configuração proposta e permissões conferidas; resultado real de testes somente quando executados.

## 5. Agendar apresentação e orientação

**Responsável:** funcionário coordena com síndico; Carolina define capacidade/responsável.

Combinar apresentação presencial e orientação passo a passo em reunião/assembleia acordada; sem requisito jurídico de assembleia/exclusividade. Confirmar participantes, agenda, conteúdo e condições. Demonstrar papel do síndico/painel e morador/WhatsApp, base completa e conjuntos efetivamente disponíveis. Exemplos como lâmpada são testes, não processos obrigatórios.

**Entrega/critério:** agenda confirmada; após realização, registrar participantes/resumo pertinente, dúvidas e próximas providências. Não marcar reunião realizada só por agendamento.

## 6. Orientar moradores e novos moradores

**Responsável:** equipe autorizada conforme serviço acordado; síndico fornece regras/vínculos vigentes.

Explicar canal institucional, regras aprovadas, como enviar pedido, consultar conteúdo e receber retorno. Não criar painel, app, senha ou recuperação de conta do morador. Novos moradores recebem orientação usando conteúdo já aprovado; cadastro breve e vínculos conferidos. Modalidade presencial/remota, frequência/inclusão ainda a definir.

**Entrega/critério:** orientação realizada quando efetivamente entregue, dúvidas/pendências registradas e conteúdo compartilhável correto. Não inventar regras.

## 7. Tratar pendências e compartilhar entregas

**Responsável:** responsável interno acompanha; cada pendência tem executor/decisor indicado.

Classificar o que depende de TRÍADE, cliente ou definição técnica. Registrar assunto, responsável, próxima ação e próximo retorno; não prometer prazo desconhecido. Compartilhar resumo necessário com síndico e documentos finais aprovados; não carteira, rascunhos, notas de suporte ou financeiro interno.

**Entrega/critério:** nenhuma pendência sem responsável; item não aplicável justificado; bloqueio comunicado à Carolina, sem silêncio ou decisão indevida.

## 8. Concluir implantação e transição

**Responsável:** funcionário prepara fechamento; Carolina/responsável autorizado confere; síndico confirma entregas conforme acordo.

Conferir escopo, orientação realizada, documentos finais, configurações e testes reais quando produto disponível, usuários/vínculos e pendências restantes. Registrar conclusão somente do que foi entregue; pendência impeditiva mantém implantação em andamento. Conclusão parcial exige registrar o que falta e condição acordada; não ocultar falhas.

**Entregas:** resumo de implantação, orientação de uso, documentos finais do escopo, configuração validada quando executada, contatos/canal de suporte e lista de pendências/responsáveis/próximos retornos. Histórico interno preservado; conteúdo compartilhado delimitado. Inclusão/preço dos serviços permanece a definir.

## Registro reutilizável de cada etapa

| Campo | Preenchimento futuro |
|---|---|
| Condomínio / referência do escopo | Cliente correto e acordo confirmado |
| Etapa / responsável autorizado | Quem executa e quem valida |
| Situação | Preparação, pendente, realizado ou não aplicável com motivo |
| Entrega / evidência pertinente | O que foi efetivamente fornecido/testado |
| Pendência / responsável / próximo retorno | Sem prazo inventado |
| Validação / data | Quem confirmou e quando |

O roteiro pode ser revisado por Carolina; preservar versão e resultado das implantações anteriores. A liberação de funções, pagamentos internos e recuperação de acesso têm permissões próprias; funcionário de implantação não recebe automaticamente acesso financeiro ou poder de redefinir conta.
