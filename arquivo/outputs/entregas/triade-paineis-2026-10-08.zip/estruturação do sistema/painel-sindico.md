# Painel do síndico

## Objetivo

Disponibilizar somente os conjuntos contratados e liberados para o seu condomínio. A administração TRÍADE gerencia a liberação; síndico não acessa carteira interna, outros condomínios ou ativa conjunto por conta própria. Não há painel do morador.

## Área de trabalho proposta

- Atendimento completo: pedidos do WhatsApp, fila, responsável, prioridade, andamento, próximo retorno, estimativa conhecida, conclusão e histórico. Mostrar pendências úteis; sem fila/responsável/retorno contratados separadamente.
- Comunicados/documentos essenciais: preparar/publicar avisos e disponibilizar conteúdo vigente; morador recebe/consulta pelo WhatsApp, conforme vínculo/permissão. Manter conteúdo aprovado, sem transformar publicação básica em extra.
- Agenda, se contratada/liberada: compromissos, responsáveis e lembretes. Retorno do pedido continua na base sem agenda.
- Coordenação de manutenção, se contratada/liberada: planejar ação, indicar executor, acompanhar pendências e resultado. Não força agenda, financeiro ou orçamento; não implica TRÍADE executar reparo.
- Gestão ampliada de comunicação/documentos, se contratada/liberada: recursos além da base, com fronteira ainda a revisar. Não expor notas internas de elaboração/revisão da TRÍADE.

## Configuração simples e proporcional

| Ajuste do síndico | Proposta permitida | Limite a validar |
|---|---|---|
| Responsáveis | Designar contatos/equipe autorizados e substituir quando necessário | Vínculo correto e histórico; não convidar pessoa a outro condomínio |
| Prioridades | Definir nomes/significado e ordenar urgências | Não ocultar pendência; sem priorização automática obrigatória |
| Etapas | Ajustar nomes/etapas por tipo de demanda ou rotina | Preservar estado compreensível, histórico e registros em curso; sem fluxo universal |
| Retornos | Combinar próxima atualização e definir lembretes proporcionais | Estimativa quando disponível; ausência não vira promessa inventada |
| Conteúdo | Categorias, modelos e documentos vigentes aprovados | Destinatários/permissões corretos; sem falsificar regras/atas |
| Rotina | Usar passos simples; acrescentar detalhe apenas quando necessário | Sem foto, ata, checklist ou orçamento obrigatório para todos os casos |

Funcional e editável significa adaptar a ferramenta ao processo real. “Troca de lâmpada” é só exemplo de teste; sua sequência não define como atender dúvida, reclamação ou outro reparo. Não planejar editor ilimitado de regras complexas. Alterações futuras de etapas preservam histórico e indicam como registros existentes ficam mapeados.

## Canais e responsabilidades

Morador inicia/interage pelo WhatsApp institucional próprio do condomínio. Síndico administra no painel e recebe notificações relevantes em seu WhatsApp. O responsável pelo atendimento não precisa ser o executor do reparo. Quem decide conforme atribuições reais do condomínio; notificações não significam aprovação via WhatsApp.

O síndico fornece dados/documentos à implantação, valida conteúdo e recebe entregas compartilhadas; isso não lhe dá acesso aos controles internos da Carolina. Propostas/orçamentos fora do desenvolvimento inicial; tarefa eventual simples não implica comparar/aprovar cotações ou contratar pelo cliente.

## Construção futura

Exige desenvolvimento: painel real, identidade/permissões, dados isolados, configuração persistente com histórico, WhatsApp e notificações. A simulação desta pasta não implementa nenhum desses recursos. Revisar configurações necessárias, permissões de substitutos/equipe e fronteiras antes de definir MVP.


## Participação na implantação e recuperação de acesso

Síndico fornece dados/documentos e valida conteúdo/entregas de implantação, sem acessar checklist/notas internos TRÍADE. Financeiro interno de pagamentos dos clientes à TRÍADE fica com a equipe autorizada; não é módulo de financeiro de moradores nem causa bloqueio automático.

Se esquecer acesso ou mudar responsável, solicitar suporte pelo canal a definir. Conferir identidade/vínculo/autorização antes do mecanismo seguro futuro de redefinição; funcionário não pode ver senha atual/nova. Substituição exige autorização, revisão/revogação do vínculo anterior quando necessária e preservação de histórico. Morador segue WhatsApp sem conta/senha/recuperação. Nada implementado agora.
