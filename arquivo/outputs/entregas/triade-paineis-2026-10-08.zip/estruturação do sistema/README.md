# Estruturação do sistema TRÍADE Condo

Planejamento revisável de 08/10/2026. Esta pasta pertence à raiz do projeto. Nenhum produto, autenticação ou integração foi implementado; não há preços definidos.

Comece pelo [HTML de revisão](planejamento-paineis.html). Depois consulte:

- [Visão e fronteiras](visao-do-sistema.md): quem acessa o quê, conjuntos e limites de configuração.
- [Painel Carolina / administradora TRÍADE](painel-carolina.md): carteira, contratação e liberações por condomínio.
- [Manual de implantação](manual-implantacao.md): roteiro interno para qualquer funcionário autorizado, com etapas, pendências e entregas.
- [Painel do síndico](painel-sindico.md): recursos contratados/liberados e configuração proporcional à rotina.

São dois painéis. Não planejar painel do morador neste recorte: morador usa exclusivamente WhatsApp, sem app, portal, login/senha ou recuperação de conta. A expressão anterior “painel do morador” foi corrigida para “painel do síndico”.

O HTML usa exemplos fictícios e permite editar anotações/configurações e simular conjuntos inteiros. Alterações ficam na sessão; o botão de exportar baixa uma cópia local de revisão em JSON. Não altera contratação, permissões reais ou os documentos desta pasta. Não inclui contas, banco de dados ou envio de mensagens.

Propostas/orçamentos ficam fora do desenvolvimento inicial. Pesquisa anterior preservada em [referência de cotações](../outputs/triade-condo/pesquisa/aprofundamento-cotacoes-propostas-2026-10-08.md). A comparação geral está em [HTML de pesquisa](../outputs/triade-condo/pesquisa/comparativo-cenarios-saas-2026-10-07.html).

O painel Carolina também planeja acompanhamento de pagamentos dos clientes à TRÍADE (financeiro interno separado do condomínio), recuperação/revisão de acessos e permissões por função. Simulação usa campos vazios ou textos fictícios; não envia cobrança/reset nem processa pagamento, expõe senhas ou bloqueia acesso por atraso.

## Mapa geral da empresa

[Mapa clicável da empresa](../mapa-da-empresa.html): Marca, Canais, Site e Sistema, com ramos, estados e notas de revisão. Salva apenas neste navegador quando disponível e exporta JSON; não altera documentos-fonte nem implementa o produto.

## MVP aprovado — documento para desenvolvimento

[Especificação Markdown](especificacao-mvp.md) e [apresentação navegável](especificacao-mvp.html). Escopo inicial confirmado em 08/10/2026: atendimento completo/WhatsApp, conteúdos básicos e dois painéis incluindo controles internos. Agenda/manutenção depois; orçamentos fora do inicial. Dados, telas e mecanismos propostos estão marcados; sem implementação.

## Planejamento das próximas etapas

[Agenda/manutenção — Markdown](proximas-etapas.md) e [HTML navegável](proximas-etapas.html). Autorização apenas para planejamento: propostas, dados, ações e critérios para revisão; outros módulos futuros como referências pendentes. Não modifica a especificação do MVP nem implementa módulos.

## Protótipo visual para testar fluxos

[Protótipo navegável dos painéis](prototipo-paineis.html): dados fictícios, ações observáveis, prévia WhatsApp, salvamento local/exportação e restauração dos exemplos. Escolha cliente na visão Carolina e alterne para síndico para testar o próprio condomínio. Alternância é demonstração, não segurança real; sem backend, envio, autenticação ou cobrança. Agenda/manutenção não ativas.

## Informativo e execução atualizados

[Informativo produto/arquitetura](../outputs/triade-condo/pesquisa/comparativo-cenarios-saas-2026-10-07.html) e [execução desenvolvedor](../outputs/triade-condo/construcao/index.html). Usar MVP aprovado no filtro para o trabalho atual, mantendo histórico separado.
