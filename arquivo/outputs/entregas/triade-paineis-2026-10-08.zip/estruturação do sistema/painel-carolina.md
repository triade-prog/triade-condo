# Painel Carolina / administradora TRÍADE

## Objetivo

Gerenciar todos os condomínios clientes, suas contratações e conjuntos liberados, com visão da implantação e serviços internos. Área exclusiva Carolina/equipe TRÍADE autorizada, separada do painel cliente.

## Organização proposta

1. Carteira: identificar condomínio, contato responsável, estágio do cliente, contratação e implantação. Distinguir ativo, em implantação e situações a tratar; acompanhamento financeiro interno em área própria, sem cobrança automática.
2. Ficha do cliente: informações acordadas e responsáveis, número institucional, contrato/escopo de serviço, conjuntos contratados e liberados. Não usar dados reais na revisão.
3. Liberação: escolher condomínio → conferir contratação → liberar conjunto inteiro → registrar data/responsável/referência → verificar projeção do que o síndico acessará. Não fracionar etapas essenciais do atendimento. Mudanças aplicam-se somente ao condomínio selecionado.
4. Implantação e apoio documental: tarefas internas, responsáveis, pendências, rascunhos, revisão e entregas. Síndico fornece dados/valida/aprova conteúdo; recebe resumo e documentos finais compartilhados. Notas e carteira internas não são expostas.
5. Orientação de novos moradores: organização interna do serviço, usando regras existentes aprovadas, cadastro breve nome/telefone/apartamento; CPF apenas se necessário a financeiro futuro. Frequência/modalidade/inclusão/preço a definir.
6. Histórico administrativo: quem alterou contratação/liberação, motivo, data e referência. Auditabilidade futura a implementar; registro local do HTML é apenas revisão.

## Responsabilidades

Carolina registra contratação e controla liberações. Equipe de implantação executa serviços acordados, conforme responsáveis a designar. Condomínio aprova regras/conteúdo e decide suas próprias ações. Gestão da carteira não dá à TRÍADE autorização para selecionar prestador, comprar ou executar manutenção pelo cliente.

## Fronteiras de acesso

Síndico não vê esta área, outros clientes, rascunhos/notas internas, configurações administrativas ou dados da equipe. Acesso de suporte aos dados do cliente precisa de finalidade e permissões definidas; não presumir que toda a equipe pode ler toda conversa. Não compartilhar senha do síndico. Futuro produto deve separar carteira e dados por condomínio, além de registrar acessos/mudanças relevantes.

## Configuração versus construção

Configurável no produto futuro: cadastro e vínculo dos clientes, conjuntos segundo contratação, referência/andamento da implantação e responsáveis permitidos. Exige construção futura: autenticação, permissões, persistência, barreiras entre condomínios, liberação real e auditoria. O HTML apenas demonstra a relação contratado/liberado e a projeção do painel síndico.

## Revisar antes de construir

Confirmar pessoas autorizadas por função, aprovação de mudanças de contratação, regras de suspensão/retirada sem perder histórico, acesso de suporte e aceite das entregas. Base de atendimento não pode ser reduzida em subfunções. Nenhum preço ou procedimento de cobrança definido; acompanhamento interno de pagamentos é planejado separadamente.


## Implantação com manual para a equipe

[Manual de implantação](manual-implantacao.md) orienta funcionário autorizado: abrir ficha/escopo; levantar dados; organizar documentos e aprovações; preparar configuração futura; orientar/reunir; orientar moradores; acompanhar pendências; conferir conclusão/entregas. É checklist interno flexível e revisável, diferente do fluxo de atendimento do condomínio. Responsável e substituto designados; configuração/teste real só marcado realizado após execução. Rascunhos/notas internos não aparecem ao cliente.

## Pagamentos de clientes à TRÍADE — financeiro interno

Planejar ficha por condomínio com referência da contratação/serviço, competência/período, vencimento, valor contratado/a registrar (sem valor inventado), situação, confirmação/comprovante pertinente e responsável pela conferência. Distinguir a vencer, aguardando conferência, confirmado, vencido/pendente, em revisão e problema de identificação/divergência como estados propostos, não cobrança real.

Débito/pendência precisa identificar valor quando conhecido, origem, data e providência; ausência de valor não vira zero. Registrar pagamento parcial e saldo somente se valores e regras reais forem confirmados. Status não confirma recebimento sem evidência/conferência autorizada. Histórico de ajuste/correção e referência da confirmação devem permanecer.

Este é acompanhamento de clientes que pagam à TRÍADE, separado do financeiro do condomínio/moradores (futuro opcional). Não emitir cobrança, contatar cliente, escolher gateway, processar pagamento, guardar credenciais bancárias ou criar bloqueio automático por atraso. Carolina avalia qualquer ação contratual conforme autorização; a situação financeira não altera liberações automaticamente nesta proposta.

## Recuperação/redefinição de acesso e mudança de responsável

Somente síndico/usuário autorizado dos dois painéis; morador não tem conta/senha. Procedimento futuro: registrar solicitação → conferir identidade, vínculo ativo ao condomínio e permissão → encaminhar para decisão de suporte/Carolina em dúvida → disponibilizar mecanismo seguro de redefinição ao canal previamente verificado → registrar resultado e revisar/revogar acesso quando necessário.

Funcionário não vê senha atual, não recebe nova senha e não a armazena em texto puro. Nunca registrar senha/token/link secreto no histórico. Mecanismo futuro deve ter prazo, uso único, confirmação e proteção contra tentativas indevidas; forma e canal a definir na construção, sem envio real agora. Solicitação pública não deve revelar existência de conta/cadastro.

Esquecimento: restabelecer só o mesmo vínculo validado. Mudança de síndico/responsável: confirmar substituição e autorização antes de conceder novo acesso, revisar funções e revogar vínculos/sessões antigos quando apropriado, preservando autoria/histórico. Não transferir acesso com base apenas no pedido de alguém; não compartilhar conta. Permissões de funcionários também revisadas quando mudam responsabilidades.

## Permissões internas propostas — para revisão

| Função | Pode acompanhar/executar dentro da autorização | Não recebe automaticamente |
|---|---|---|
| Carolina / administração | Gestão total da carteira, contratação/liberação, atribuição de funções, revisão de pagamentos e acessos | Leitura de senhas, posse de tokens ou autorização para comprar/reparar pelo cliente |
| Implantação/documentação | Clientes atribuídos, manual, pendências, documentos de trabalho e entregas aprovadas | Alterar contrato/preço, confirmar pagamento, recuperar conta ou ampliar permissões |
| Financeiro interno | Contratação necessária à conferência, vencimentos/valores confirmados, situação/problemas e registros financeiros | Conversas de moradores, rascunhos/documentos internos sem necessidade, senhas ou liberação automática |
| Suporte/acessos | Solicitações atribuídas, checagem de vínculo, mecanismo futuro autorizado e registro/revogação conforme política | Ver senha, mudar contratação/preço ou acessar carteira/dados sem finalidade |

A autorização combina função, cliente atribuído e ação permitida; Carolina pode acumular funções. Só conceder o necessário, registrar responsável e revisar/revogar quando mudar função. Matriz é proposta; autenticação e isolamento ainda não implementados.
